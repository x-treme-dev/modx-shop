<?php
$_lang['frontendmanager'] = 'frontendManager';

$_lang['area_frontendmanager_frontend'] = 'Frontend';
$_lang['setting_frontendmanager_frontend_css'] = 'Стили для frontend';
$_lang['setting_frontendmanager_frontend_js'] = 'Скрипт для frontend';
$_lang['setting_frontendmanager_frontend_tpl'] = 'Чанк панели для frontend';
$_lang['setting_frontendmanager_frontend_position'] = 'Размещение панели';
$_lang['setting_frontendmanager_frontend_position_desc'] = 'top или bottom';

$_lang['area_frontendmanager_manager'] = 'Manager';
$_lang['setting_frontendmanager_contenttypes'] = 'Типы содержимого';
$_lang['setting_frontendmanager_contenttypes_desc'] = 'Типы содержимого для вывода панели. Через запятую.';
$_lang['setting_frontendmanager_manager_css'] = 'Стили для manager';
$_lang['setting_frontendmanager_manager_css_desc'] = 'Для скрытия ненужных блоков и кнопок.';
$_lang['setting_frontendmanager_manager_js'] = 'Скрипт для manager';
$_lang['setting_frontendmanager_manager_js_desc'] = 'Для перезагрузки страницы после сохранения.';

$_lang['frontendmanager_btn_edit'] = 'Редактировать';
$_lang['frontendmanager_btn_users'] = 'Пользователи';
$_lang['frontendmanager_btn_ms2'] = 'Заказы';
$_lang['frontendmanager_btn_context'] = 'Настройки контекста';
$_lang['frontendmanager_btn_settings'] = 'Настройки';
$_lang['frontendmanager_btn_log'] = 'Журнал ошибок';
$_lang['frontendmanager_btn_cache'] = 'Очистить кэш';