<?php

require_once(dirname(dirname(__FILE__)) . '/mscustomerprofile.class.php');
class msCustomerProfile_mysql extends msCustomerProfile
{
}
