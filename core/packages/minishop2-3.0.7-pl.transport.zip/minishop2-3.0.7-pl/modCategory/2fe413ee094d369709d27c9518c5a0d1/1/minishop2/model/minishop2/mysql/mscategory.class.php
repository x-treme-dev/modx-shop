<?php

require_once(dirname(dirname(__FILE__)) . '/mscategory.class.php');
class msCategory_mysql extends msCategory
{
}
