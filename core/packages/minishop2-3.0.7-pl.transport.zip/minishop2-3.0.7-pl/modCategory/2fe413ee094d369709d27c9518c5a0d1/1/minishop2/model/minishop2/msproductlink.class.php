<?php

class msProductLink extends xPDOObject
{
}
