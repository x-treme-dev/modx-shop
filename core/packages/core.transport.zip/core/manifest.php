<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '873951570f827f4b0a311f0b76edc4cb',
      'native_key' => 'core',
      'filename' => 'modNamespace/c3912c9d824f1e7ef4ced1d5bb41d51d.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '205327ae83e02e4d9d93b3565e742560',
      'native_key' => 1,
      'filename' => 'modWorkspace/7c2b41b0820271042fbe6a6a0f0a72cb.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '4ea1952c6cb517489093a53fedcf7b16',
      'native_key' => 1,
      'filename' => 'modTransportProvider/8938bcde56c972e3cae2e01c518a96b9.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4f8219d114562d4bbb125d2a8428354b',
      'native_key' => 'topnav',
      'filename' => 'modMenu/e93ae2dac93c22c9b4c4671605045dd8.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2b8f8dd9dfefd8925a95e9d5c6c74fbd',
      'native_key' => 'usernav',
      'filename' => 'modMenu/618e26c094426f4c6f31730070725cbf.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'cb64e94722c8da8e088648b803969439',
      'native_key' => 1,
      'filename' => 'modContentType/c5c6b4bd95b4750f402235864fc83b9e.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '72fe1e269213208ede18bcbb15d360c5',
      'native_key' => 2,
      'filename' => 'modContentType/d3ba7c0873eb7cadb581d8e96eab40c1.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e038922d2e0593f69aa41128532f34c4',
      'native_key' => 3,
      'filename' => 'modContentType/33b742683612ced9c067f04519677f3f.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '904c14656ed0d05f6178f0453c721ede',
      'native_key' => 4,
      'filename' => 'modContentType/d37463476219d9291dd0f79d56bbe774.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '95cd2156dcd7a14a269081bf8608e58c',
      'native_key' => 5,
      'filename' => 'modContentType/d5e23b9a3050360b877d33e8518ed747.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'c9c41192eea86966dfe39bc30aaaac45',
      'native_key' => 6,
      'filename' => 'modContentType/5ed4ad00e637c2ffa7e90777ee57bcf7.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '2c611751582319d8bcf58046327fa8dc',
      'native_key' => 7,
      'filename' => 'modContentType/4db0e75f29d56ca7c4733d07850c8ce3.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '44487c54009ded52a5d0400f0309e35b',
      'native_key' => 8,
      'filename' => 'modContentType/b14d4a6f5efa33318361d8838170e8c4.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c7d308566eec07ce84d23275d97d1426',
      'native_key' => NULL,
      'filename' => 'modClassMap/134f406b1cd1c997054e27155cd2d1be.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'cb604245d0fcb61959e7e65e9658f25d',
      'native_key' => NULL,
      'filename' => 'modClassMap/832c017226343d434207934c607bc18f.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '5cfa2c827a09cf668f98d074e9875bb1',
      'native_key' => NULL,
      'filename' => 'modClassMap/8314166ea0c8b567618ec2eb6423081d.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '1dce238aa3df67513fa4f31f2f2e2c32',
      'native_key' => NULL,
      'filename' => 'modClassMap/94947b58d226c8113d4899e31729602c.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7457ee73eb6a8f10085d5897e2144f93',
      'native_key' => NULL,
      'filename' => 'modClassMap/d82d0315579a937c8d9b9d28c96cb54b.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'b1703210076e8cc929b5c6d4ffd2a797',
      'native_key' => NULL,
      'filename' => 'modClassMap/d6f68450b4e8576bbc684aa5852467ca.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'cae172cdbb88e1474964e45be45b4da0',
      'native_key' => NULL,
      'filename' => 'modClassMap/1ac258c3ca07ae70abc6c801d2355cad.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'a3714d7f6e8dc276448e237cf967dccb',
      'native_key' => NULL,
      'filename' => 'modClassMap/8477825ce7cca9c1928014fc7951e649.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '71946e1c3e9e0e1c85ada60b0c4ef13b',
      'native_key' => NULL,
      'filename' => 'modClassMap/86e53d77086107157334006726bc75f1.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b0fed91a8866a5ab6b6da999564a623',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/202e54b2aeb1841da1f2e48d6fdc992f.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c44923645ea41881f8dad33f8df4e0a2',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/82328330ef7c555fc5d93a5528516215.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29162aba20eb87ce282ab777323865b5',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/f3d9a737e7ea3e6e341c750cdfe8fac0.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38f36f1edbd0bf23419b820d1cbca226',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/03045ff7d1c8918182cb7c30d5d557ca.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5fc73156ee638167b20b7e6601fd6ce3',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/e8d6dc8ff029cbd228e5f26ab5083341.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66232889189854cfc67b9a807ddee98f',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/c5d6d56c43a65b34e3f213b1a82756c8.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15592dd8a9e4415dc84774a5bc63b6b1',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/a9c74705601703fcc61c27f4c619d095.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd8b17e31b7b1df3ec68e1d439fdec9a',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/146c01727949946a06ff0503b99ba9a4.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '71c55acda397472de1b97de11225a9af',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/021cc067ad030a6d4473ecaa39c09038.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5771fa3e04526211476d664c93ff3df8',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/98971f5eba163c27ee0c64aba533e1e2.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c8ec5ad204af81f79ce412c9db1a78c',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/b768aee0fd3149fb5322df651183ef97.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b2ea0accb71acb621295eb5bdb6fa679',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/d1d1925856bf20806a730d6a391f5279.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'abea969276cb5ae0622ed634377206c8',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/82bd591f1951d4b8dde40dda434d6b34.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97a8298c5b2c51f23988cf2b5c9681e8',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/42990203d32fa0cfff54756ae150053e.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9be1900fe5d0a945aa118ecda20f182f',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/2b3a899985e9cc77a441af2bdf584eba.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6b79a8581d45efeaa188b7353a3e34c',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/f87f8545651025ab42a59e912fdd5291.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2552214f580b643f2c64aa7ed636505',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/05e294c50fc06069591357a040dd8f48.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6db85c7cc4d25745529d9e57b8ce8cdf',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/661ad32537a529cb4ab5b0a3d2e5b95c.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29f90623d582b22bf884428eaa18896d',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/93ff176d369b8cef7e6c873e2a94351b.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '626b3d9f29628fc1e5eb65eeb4eee484',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/5cd939d528712ebbcb39a6f89c78872b.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91aeb995856e2da46d7cb72e0f4ca6a9',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/cf3924bee6eaad6860e34ca47d1efced.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0ce68986e84549be1ec64c8871366d7',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/448c2e5e3f5eb47a4b267714ca429d75.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '207318eda1414e27eac6d96d27766a29',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/29f8752b72b2fb7178e26f1191ecd9fc.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7514c8828823fae1b69bbd6e26336752',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/bba404d3428f29740832136d1544fd0e.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '093f12e8664bb503094b3833a63b1259',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/e05bfbc920d673156fefc9796aaf49be.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c1786acb375236f764b5afa06b5e71ed',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/0f888b16ff90e25de1f0b8ffc0c1fc75.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c7ebf304035244ee6627d46f45a9810',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/7660d13c6a45224eaa4e86354c582499.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb567223a9da7dbbdc83886d4f8c706e',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/fcb452dace85bfa3959973668f881113.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '135158071421cae5131a3b93f4ad570d',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/ac135aa62ceafbe412c7823fa7573604.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d26fb7f25df4997931808603216e285',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/9eb8264286d7a62c80c192a3854149d3.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '977176184bfbd4383ab540d107ea3c89',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/8a05306e804d6cb1cf0cb43186ddb67f.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0f1912f90c39ccdf5c483fb1ea525be6',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/3abd6c4ae473b5bd986f8552b91a9db2.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfc020f3c679d1e45c9c2141cc5cfeee',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/0d6691897efb30cae321d76df87b67ca.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb26e8992251f9a70f253b807bfd4a45',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/9ad9dba1067959558636a92137915fd8.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '50c4c9689285fb29f0f95023402a075c',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/2a1f524de254cbdd22ae6e0e7ba409b8.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e23ed09b61c4d6748e18fc84e5b8c301',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/9786d0807190ff223532f2e1eb9d7f4d.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa99218b5460c4774ec4a64af6923800',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/d051230318317019d3bf87e39ff7bae6.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a808689a58aede618d9d6c0b15f322c',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/41a5946956c7cc669aef88efebd8fda3.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc47ebf63217a969b8304587454aa910',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/11a7f6da70df37e8b4be0e3a5fcd8ab3.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c1fe2888287b38eb1c4a9f977ecc0467',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/e380223427705060c8dface5cfe88838.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a89c69638a7bcc9dc2d5022106e3cd34',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/23f18635ae7e814ca8acbe9eeb299725.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84e17c57cc028c9d97315142382203a5',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/13a26915fce5e465d6b9e4a3ff1894b8.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc7b9260f76068e6528b9f10c880de7e',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/399b2a826ad2e4a0896d37020aa9d1aa.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '54e246ea658c8ca36064745752c1d247',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/88c80393a3c6fa40251e714d2361dcda.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f58b206b58a1e439aeaa66ff5482992',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/8bef0abe410a38a00389ad62e634a07c.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '521dd83988dd29341a13ef0abc2e9a4e',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/d4073616dad3a09fd9a3dcde60d79f50.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '667ddb0bd43e28a3a6b6bce4e4c6679e',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/9dd67c4a340e54ba10ce2498c8eaf4a6.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c291dceb5169725f9a52d6c89febcb2',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/446ac8510375c643b1fe45daaac7778e.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '789d3976e92a8c6ef5cd58997a63024e',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/1ef2078591099af194cda2216bad9351.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a16e9938b7a1fbd248a43134ba30e44a',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/9c92c33035a4504e48a97a1526d970fb.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '091ac63c796626edf95e1fd715f59ded',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/a282d308d5a9e9d0e1ec17f490765042.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0aade38d747f91c412e1f9c0068ebf5',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/8fa68656d3d05fd9b3a72b21985d7cd8.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'feb1ba311d783ab26ba269351a39063d',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/964d1fb632b1ca27b75dd7162245c3af.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17bd1236d637454b9e9088ab0ec942c1',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/468f4ec463a4b8fca61f8754292ffc66.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2ea3f44181b517d90e663af7712d11f',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/4b9016907d275ace0f73516f0eeb698d.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c227d1eead6ee623e4053ca24f883bc7',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/9b770be81b21c01864962c12135beb84.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8980d6de2b3bcb97227588ca78b6a234',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/a082ff4881b545fb09bd2b9863b19c0f.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58a681ffd83ce09773588e25a8498ae2',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/d4a5138355b77dd3b02e45d690571460.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f4f3b7dce45b3ddbf1a75ee9e931521e',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/94dc65a7c0b646ed6b146c0dfb33e142.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0633e75f52e5224699890c5c150777a',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/843d98d54670af5e077d74bbad3eb6a8.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc3fd9f1cbbd1430abfc41c67c720fcc',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/2413eba8ff209f22026328dfbdf9df90.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8bff4adb437275319c69d9f6e409f9f',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/f45fa48f89d7743b3e51cb3d4cb2ff6b.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95e3fd82ecbdb83f9d90174f56490333',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/9e30787ce5c6f68b94f9b397781db478.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a65d6a793defd627ba72cc37c0ed1df3',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/3d8c411a23342bce581b6d8cb52497ae.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15e5db0571a14ca81140d256c911c6ac',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/badc0d75bba07b550e8d00ab6f2fe640.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0d3e553218129d88accba0c01dcedc7',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/8051231e5a9b11983a2251bf1b0d6c9b.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7735d60cd041544427a06895fd27c5a5',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/c26ac58b93f9c8a34c3cd3392ead3a2e.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4699a2af524f9ec67a7fb0033824b16',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/07c01622c2baf1cb28f969537fcbcca6.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2ab8291abe20cd1cf5108961c69ba21',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/e8f819f81c68d2130bda03e619815cb8.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '34e36abe52f95cac766eed18304f838a',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/277663393725644a0ebe9c9756bd6965.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ee1fa276ca8a2185c5d8d7682acf7871',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/0369d474c2b18c6e085114ed4d682b66.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f89b4d386db0396962c744c7a0770ca3',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/33df7e7af29b20a7fe2a9817450392f9.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78995a9e661f17255e5699d7d4a43e9b',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/963469f0a024cdc2aa3a9f235be004f0.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa7c2fdd01264a90b82b80343c9879cf',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/7d3ecf10535110fe942aeee94cc5c419.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ff4c3bf0cb8135e30e1e0e5b4ae9147',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/d5a50ebd7a4b56e71eeaff3ede65c64d.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94fbfe1109089aa22ae0a1e096d9ac03',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/f62381901aadbea11856de8e459e57a1.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa90a1bd66cb1e83b23d3d5f347abc9e',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/4f0638db97311f672793395f2d5811b6.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2082d000905de9ae67bd4eb859f7d561',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/b4ad9a93d021bb9903ee86bf05de1ff3.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '434a16a6c538de77593372275641a361',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/6f5eab30a0b0d668da20ff69f3e46a78.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5ce9c47dc0ee7dbb76e6ac7ba03d39b',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/c048e41a112b86a2982c388e75ec4c09.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2e54b20e49f232ae702ef53d9f57374',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/ab721b6eab23209975c63e8bb4945f25.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '79120e8f9c310d52f17afa16c5ffacc9',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/12c2c67c77df4e9f9b034ad300486d71.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9dc3bcbf487aca8822a63a10b36b4a3d',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/8dd7b905cc23940366b74b5dbf286dd5.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fbe930dc0a26744ce4c08b93409ba3b2',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/ec1421e942a61dae38d02bb685cfd062.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5d27cf563f5c76ed530fbc66a967285',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/4bbbfcfdbe5357dbc63e675cbf23e313.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ede5966142c694d3b78a8f9c14d1eb60',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/fd60c5ec3468314e60c9a3c9c0345d3b.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dbbee6ecd750b15627b4130d4270e234',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/6afd94399b800af06ff0222853e656bb.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9079f911d9cf0ace7f3520ecdda59841',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/6a695d383c5085f064da0a99716d9ac0.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c7a1a3a3c9ea7fb4f13224a7edf2b5c',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/266bf19ea88bf58d9c10e64bde146978.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6edbaf3ea29a0c08d41327c877faa359',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/38ddca878d72054eb9d94e12240d0307.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f06b0b67b07febd6b9ecc72bf6705012',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/ff6c778d3375d3c5b06d3923e844e5cf.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cdc9987ee5bf8f45a2d21bbe8ce12b80',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/43ad0f4224b26f20f262d9e6a8c24591.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfe1f18b54f9c7d1178cfbe8bf1eca71',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/65432bb097a83157ae22ae7a561b8389.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90f783cad67144e1e0ae727822d09bd0',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/821ef061727d21f33720798e7e857dde.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e0a573407f2fe88a7ff66063e10ec37',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/1b164eeac64bdcd835f45928d29ced4c.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09d9fd929eb372e39908a91f3fd87f8a',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/aea4cd1e72e579470dd543beb71be0f2.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b093f444e2d163c2990bc42923f34576',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/565e6273a93322609f7f347c7843b671.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3507f97ba63052335a4d01f21f5e5639',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/99c0d81aeb57335e9094ae804bc89e26.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff75656e04392200a79fce7ab13893b4',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/8da0d446e0e7700463eb9aaf0ad85f7c.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2aa9e9c7a9ade2a97675d99538a810e0',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/2d60652339f633cf86067ba7228bf209.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83d1998798e93ec0dcd227f825f86732',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/723576bee3d87ec35dbfc6a37ca47a4f.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5397758c4c020270807e2b210daeb160',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/a97ee18715bd2bd02f6377b347e91f07.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2358b7d17f875d44d6987f23c49073a9',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/c5c2fdac1be650718336fb4586cbbd1c.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be2f798632f51f65d2bbcd7534e0def7',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/7bee24413fa29e404724b9ade6845e04.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b45cbffbaf6c24bb02b04a352760481d',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/997526b9fcd9f9b02d0773cf76123629.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7cedc5a80ff942a7f316d29071b17ec',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/5cb081746b5e462d525a9aea3def6bb6.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5acebb1ec62010af12b8f9bfcc5d9013',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/c5cf3b161b377745dd8caa2b4fe1c61c.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2c236c303d99e74a8cd00edb2b7d0f2',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/813698af0b8f1bcfc139b530673656a2.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96cb96bfaa4aa32b51f139cf2cf09a89',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/37f1bda85dca99f1dd9b9ef0f7513fe5.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '853c686d7974c009a4c0ce7d09bf5cdd',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/05eb7ceda450f8a23f8f399c3b645fd5.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b69f5e601dca2adfc2128e7d49c81348',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/86d81ab1acc979c9446798a6bf0eb63e.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0e7921014dd691f8cee876615803b77',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/07f3e2e0622a29a8fb093d920f222128.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5353160e5e4e5dc18eb73f8ed91e2b01',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/9f2df5bc6cfef9d09d6adfef551dd88a.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ae0b8c713dca0b4bfca9162d1d40568',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/3ce92c42405e96175c6cfe7091ea26c6.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37254f13573732c07f5251024517ccd2',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'modEvent/8905a561880a8db2a685af113159c0ef.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2829d5fb8bfeafac56d787faf3a110b7',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/33dab592061e154aee2120b833c49f4a.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '35f4294275f4f5ba114ce99bf39abe97',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/738903a3e5e1c2dc0b34d4e21b0cbfca.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '180c8282cb23d21f72b209739a9285f6',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/787e7170372190388fb1794904b62a64.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eddbaf1286f19e9a72bf4d73e996e5f7',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/f8e195a16d8620dc7c0460d66c1bff76.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f822f54205dceeac6030f65cf95e1476',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/c1e14de7f798bdbc3f91f575dfed9cce.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f3f65d3a705caf93ad61dd88253f6e95',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/293e4729e5f09bfc7c5daac3c8694f9b.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a9b7ca9da591bb957774b63c92daf978',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/b79ce76c3f76fd10446ea8dfd0c6a596.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '745b6fbeeaadfbb87bf133b321a8ee31',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/dfad3245cad42d14d22bc5eee09c1e42.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b50a4f3129974016aee319529c60598',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/167be7f1665dfd3845d0e1e24d111c48.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d16046a2812893eb502b2d856e505a1',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/185c19ef35ed19a4c13dcdef3ec4e115.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0559459070b0543bdbec8dd43dda3e04',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/5686edb209f513c4f8734529872b28dd.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1790307df293406298a62e3832731db3',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/debd747820b76f3b9455fe73a14b4ba6.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd026e2ecf61c2183412a88755e0cef1',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/58cb7c6d4bde5ab3f281147c19b87976.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '346842fba64edc727a5837dc0cb733b7',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/a05bd2f8cdc656875d44d195af8baa8c.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09596d8196d1583b2007bac6f771cc93',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/c5ce474a41e303fd37bc445bc3d2e630.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'efbd9623b92e5765e1cda120d55cfbf5',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/13cd0c3f86f9e6d6312bfccf37a2f36b.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90f1ab66b0196e7bd4fdf1b988eaf23f',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/0b5d2956cffc79eec2ecfcea25279d9d.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed8fbc3a36a754acb7182322fae9e3e4',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/c8b4b5beaaa9574011cfecf66f67423f.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cdaadd3a415246eeb34dc2870d9c2caf',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/acefa3994b05a4d28593249ba33bd700.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd140c7d42759d80c2586a8fee3b8e63e',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/0383f7793ed92d31aac837a49709dd65.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7165186f485dbe824e88179306c44735',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/080dbd8ced160d0b542ebbef02716af3.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba6344ea7052637c87e55fc72fc6de5a',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/b3381a450910640fcc44f90382283c94.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ffd50e39eb9a4ce3766a76af4ca6c05a',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/e44c30f42c02dc34f1e65c5f041ee35b.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2adc352a3aff94229e792db438eb360a',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/e3419b6a1d21980b01ba9cf4be744f5c.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f3735598e4debd3a4b68339beb439fd5',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/a5f53378d5c88d09a32c54eb6eecbbeb.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c20a6d5da8bbcde84fba0a6f6e12663',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/5bf76f466faf6e95af60e1363f9fb52f.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11d64412e6e6630b251bec9cec7ab644',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/e6b188e3b9d8c7bf2f16fe1a40c7be8d.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba06cb80f7b378788a488fb735cd4e50',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/73eeafe47470b9b39b0b6ff500974d24.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df17ffc4c1148b38282cb835f288d5cb',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/8602c91076bc714a71fe7ebf2c61f930.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1afcad4601c17ddbd305b4bacb21afd3',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/87747b2aa52e3b84c842426c58a1a663.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '538540b826f3600c542bd9ba84cea59f',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/91b73fc1c928b4ca2f628cc09c7a105c.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3ca3783bb0536bb92b7d8d736c6687b',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/d5f7f0fd1658df4b2cebfb148adeb095.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '13a374d969049e74534e6b0db075e21c',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/841471dd3d289d5d41ba67bb5f10a1fb.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'abe3d059291e7110d6d47276e3168e44',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/6b75bd1526fbcd875a87b496e719eac3.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d5fc4c258bb4bc09972ae14883631b2',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/277d10e3d5d00291d42dd05df1d3b893.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '895f3ea499ca0fb3d5c4cfc8da78cd6a',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/78b36be0eaf8719928242a3765e45cd9.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '609a5b343d9584d79ef7acfda15c6900',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/11f4e90a27071ad25bd168ce6b2e4472.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f62551b30d9f8b126450aa7152ad73a0',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/4cd929a4acf7504ce2528dfc12a86244.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3cc255327e400c45d05f99fa2ccb8023',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/c8462927e44cf4e021504810ec11b6fb.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f6b554175d02d1389898cafa5412ec16',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/aeb73b4a4911f5cf5f65fab2e6633591.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f256df94297147b61836c5b04c54114',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/30385e254ace2992a75688c8d9a98a9a.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5407fcc1fb68adb1525300c6c6845035',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/0e476d1a135ae40cd4d09eab5a74ec1d.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9dbeb7a5562101fe4f264ebff497ed90',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/5fb253f21c3cdb03f0761b5ba75d7e98.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4041555ea7c7631eae2b2e6afd7dd96',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/8f927a67886c4596220dd0066410588e.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f6426da073d55735847fa1dac7219de',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/118d8cd8b1fb2cc3b121e1b5c89ec086.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd8ae768c8e3e5657c296b99492137be',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/9457c5a33e6fc5246313a523a5c846b7.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f508a70990cbaf0ba79fa6b6e77fe28d',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/e97804dd880c48ac798c2c148162e9f8.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd2ff7a47e58d26e10b6bc77ff6b111a0',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/15116b8fac0fdd88d3260cc6e62b59e7.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5545128844fbd58ca7044cbe55dbaf1f',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/49803c7c52ca3b6c58b2c14d71b7cc7c.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '63d2f36cbd87fa54ea8fbbd09054935a',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/024193d7ee20781d807321f24a50be10.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab2c4a4306c55c03cdd6290acaf0e13a',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/5a78a56a44b95f0c0a4f774b7a79f5e4.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c1a5881a96ae27783ef89a976d1a8b8',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/21f57fe167202af11b08c891fbf6c58e.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba15c097979ebbef8e678566e850d895',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/7cda3fc3c6a240497aa20339a6fd6ca1.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e52a27d36010358088d8231ede09ff28',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/ca35ba02492c61b2e3f8e42f85c6a18d.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bab931c425983406b266442333f306ac',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/ad7ffe1ed3ada749af0ceb387b7d8662.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55d1f152001091792be0c0cc505bd5de',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/f0bbdb734cee6239c486e2c9ed6346b1.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'feb26c973d0d22489d18f1774f3caf88',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/c680cd2470b178ea58845e96a15f6fc6.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dbe2c95c85f8a5043d334af826e3acf7',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/4555b3f6bb6ed418ad578d2d33758572.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f4b254ba22b086ac22ff32f15e8bb92',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/627f209475ac4309edabc42fd0014428.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b8d70f0ea6d0a4184b39f6525af7291f',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/ed67112976d7d9fe931966b3be03480d.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '278870dd0cd5e0ef209a23ad1c1f2715',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/37152f0183bf3f1a50723f0823d17fd6.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e94711d36632e1ff5307e236b1a4242',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/1d6b37b0c58e6f0b93d99818ba5a8044.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5371d3d499918549d2a68bdffc69f07b',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/c23d3e3db61eb9ea1ba0916de11114b3.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f819fe6cdb3c881125894b59c2341f83',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/4c77312bb90bebf1bf015b3ab883d417.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eab11fb421d21e4e665d84cc57d218de',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/ec74b12df870847ee0b93ba180757e2d.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b6a9b758517d3c323599c9c05ed241e2',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/15f663b5eb8d3086c8e2435a1bd37ec7.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '87cff7197cc49e69c10ca55a52407e75',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/fef7b3c7239d96d5699bff5ae0620838.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b10ac698de2ec986e3b754bba2052d62',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/e3882a6d8a2266fbc76f9a5b4f9cc91b.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f5a4ef2c9d4dc4e7c9e189a80873d1e',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/5781608dbea3ec2e776d2d7f2ad0485f.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4273314acf5cf9483efae0a12322137',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/1f6e3236b5a33c80c5f815134977a727.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd65b78d9ee6aa60fb19f9144d3ae6c98',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/c03028cc0faac8956805cbc53e20af89.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ab893b5225785467a3e213e415b9427',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/20cbe2cd80b50bd2beab0b091aa21e2f.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8cc22d2a725cc97d35379602de79301d',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/d2e7386fbe3fd2793dc358967424132b.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7b4fcbbb14d6d96dfc59b9e07aef5f31',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/ba77bfd613bbdaab96cbff7c67562a88.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55af543f3c9c8705959b74bbcb1dcbf2',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/6b120aa4352fac2a358dd20f2a0b7593.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4dc3addf9b811bca3d30e84804aa78e3',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/c3c8158cbd866332fd36af00fcf8f898.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37ee632fda1e4a5669c0b040937c64a7',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/9e245b2101aae54d926872161644d7a7.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80ea5f269eb285fcf9d7bf82d2e97e30',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/3b2139e574a8f1e05db744bbd02d6f1b.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef0ba46398a7b7e831c18c8f8f893361',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/ba60cc25887e7e667da2880052e5a1d5.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9269002f2f19c10091319fb279af6d5',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/bc459ad0c7357f3d169521c3eabd841a.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '201b79eec540836c2bd9f1c123072a52',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/733ffdeaba91b7240f2712499dddb8b8.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ace30fbd558401cba306cb66df645510',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/dace85544d1298766a0c3ba57bb7600e.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee6cecc5b0ad6e6b6fe3496726e64e2e',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/67c2a1a40057a70f7f530a16348a2d16.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60fd7d184d4faf83a176462b48838d1b',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/4216eb4d53dea741fa24a04945ef8d85.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16803acecfd029a5dcde5a4420e59fe3',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/bdbc7de3963bc636a3d6e378ca4b799e.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e37dddf5df1536861d68cff55826265',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/87adcc8a405b426b2bd1cb00bf0608a6.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02b597aa721efa890a399c0a956de23e',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/53f1a0819bfadaed86513ac4f2e19b81.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0d3db2d424d00ff11d42d805601d63a',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'modSystemSetting/473e89d4336116fd42d43e0d72180235.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b5ac7e7db8e6cdc3974e0d2f398f711',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/4991c9a39b56d70513dbfc8954c0bd42.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c3b6aa6e9aa77ca2852012177cf27d4',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/c2b6ec3fe027b1f1bd67ea8c59b7dff2.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70d4f23c1d4326633490b796ed7a5eba',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/04d3e92f8a3001adf8a26d0dc980cb4b.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4551d1ff29bf8982c9e178098430f168',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/88e7ff88f2de93ad982aa3eb2705b20a.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '156b5b513752abf5badecc2eefb90584',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/638f75d6b3d03e47baa1a40986b2690e.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ee4317bf3a6e3925bdc0bcd734441cb',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/ac9018aea4a042d2019b139f3894d8d6.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a260ca4e0ccd957f26b3e1661ea6a2a4',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/b14d4421ee85086cb840c14a28e49aad.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6701d2b67bc7362ec04e2c1b8cf6e4c',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/9bcc7cedb674f25aaf38cbee7fe2908e.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69cfa75bebe23beb2c4e5d331e446181',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/65332dc760594c50923b8878eb134afe.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d09d110e9cdd044aba11959cce03ede',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/d5dfb5f3f5a9c928579d494bb15d5eea.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '252956f057b59ba123281bba2f25b61d',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/ca13678f47fa4ee8bbce173bf71ecd53.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cbb29d7e484eccd4e46e09af59e53c4',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/2f9fecce5e339d57f387f88cca724e4d.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '571fdd276c222f8b98627c2d3edc8355',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/85e6e733ef0d6d6d6105c72f1b98edd2.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd9ddd1eba6d2606438f48717ed34b1b',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/9086b230c4b9b043f10b4c32c65860e9.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '528c244c5925d73c3f09163b26f0885d',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/2ba5aff048aa2648f222edbeec1f2075.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc1eb15f522c2b7ded256b9ab6ce9e17',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/ba3f0512f8520790c44ff646599c730f.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7e9dd9edad12d8abd85fe5c798c826b',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/f9b38626f57f7c0180297db0f1d38048.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e866a7f5573f0fa27e178ea8ab7c084',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/23162d952ceb138d70c353619d500f71.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd570cc709cc45ba3f799ccd9724321bc',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/2e2bc93dd5927fc215f506c3af429a31.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a12d0eb0b06d78335c672cb9f3a39f7',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'modSystemSetting/6d0f0c062d59ceff2ddfde050ba45843.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ceda11cca3cc318e91a2c5553f46e1a7',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/314c30afa657c0c73a56fe3cb8077760.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a6f6717cbbbb7a22cdeef91755e46b2',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/5e314bf3237e86bcd7b1a92d8d99910f.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f1bd6fdc5eadebad18e7294cab9586e',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/ac7f67fcd82a9eca20933a604387901b.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '111c35088a5277300cb772ec34c305f2',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/68fdde03d1ab6c8f3ec7d979c825a873.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dfd0a490625fe84abb14ed5d8899a792',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/f6d271df09bc284ef23c65dd906935c8.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4690600516bc4be8b221d14a3d6285f3',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/bcedd975f03e9cf5fad4439f5fce4ae0.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a54e2eecfabefcee363291dd6cde312',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/baad787d315550976ebd1ee7d66f3b2f.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19f9a14cbb7c4c81195b610dc5df061a',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/35103f74fcdc480427326317a28941e0.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ab4c84f6977bbb053bc203700185bce',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/dbcef62e5eecc9d8b62825383ea13cd6.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7cd6306ec11edf867e6a8a5af8a22c80',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/1bd51eaeb98cbfba6b0655c166e1e3f6.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b60b9c4b6b673b5ca9cbe3a04e7e86ac',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/1aedc5734b74874bfe80a33648198178.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b58112cc8429276733ca45c909cb25f',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/00ef12a0cd5c8db7f85634d2cfc320da.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f7215718e894d8e59b21b48c545cc60',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/53dfe7f9ca84fc78b1bc78d26ace82fb.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41b5eb10be03d17e47030098bb4a5858',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/f9b5de3ba85148d410f5dba50fb55b03.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f901fc6b0c32ae55d50b86b1da80311',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/6e44202f64e101bfe3fbcaf28b4a018c.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28068df54691b4bc62bdf0d26b5d00cc',
      'native_key' => 'default_media_source_type',
      'filename' => 'modSystemSetting/64759d9c7a71f6d77dbe19cba5f181c9.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8659de2f34f22a6c2ba61a785c4531c',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/d361e77482f2e9086c374234fe985fc5.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3370f200e91e9b99569dbfc01d682fe',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/dc8782b5b6ffffaca349ff6464782c29.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca4d63a9b3d8857457856e80d77b5837',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/7487b2a74c09ec512c1823f45addbac8.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee4bcae4b32a80a9515c85cc5a922506',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/3d296102ecda614eb5db068157aa6071.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b98a2974c00aaac9f7606fe8bf5c506',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/7b8c24a8049898cb04c39e1b6f97cd55.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d679e3aa9b395ab98659bca1f7749e4',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/4054061463b25ec57a8bc75a01639a23.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa7357fc4626bb801680dd8e9315f29c',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/ec08794a23083c5c71aaf2352d5ee41f.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0f9f7d546b95674779d2d288dd959b1',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/97761a6c71dc7e0ca429c9cafe848c95.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ee762dc9d70386e78e0188539c580bc',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/3765c0865dc8e0f4731bf9a7122f8a89.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80fa9cd70e5c8aae0d4fd3a3113b7ccd',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/51f33bfd25f7a7a4ba6d559594907ad3.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29fb09f3a03d658bc86873b9204d853b',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/49458a7d656337b36ce5997acfc41601.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa0eb27bf69ca49b817b2ac73ddb9a1c',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/a77876a8c2afb0532c53edc85ba99974.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1df6f57bcc7a078cdc345c83e64919c6',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/4b403abf255e1f23ca782b00adc42fd4.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1dfec9856ee82362fe34763ac30241e',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/21b8482964df787d892b6eaf612fcc32.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35e0d70911930f94952241143e665acd',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/657b1303fa6de2dbea98aa1e4f7f9866.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b5b0c893612028dd6447800966c50da',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/7a1fb61352081edfac54aa9f89ab14a1.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3b401a58e17659af25e89dd3bcb1ba8',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/744025a9ba88260a839dc763eed7c8d9.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2427d70352747525b09466dd0c0bbbe',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/63cc9dadb979dfe411f19c34673a1ccc.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0a143a73439a70af86504e62c5bdd14',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/5ba158a2cac77c1717937804b159f203.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65bc92ac9b9def25a073e337872b48c6',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/fb178adc226e26f39d3be4aa934f5b1a.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ea82e2bfbeb5a99f792e1fc636d62bf',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/cf57d636d28b9f10a25bc23b750a3aca.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe751e5d6ff3ea07f53f7886c9fc04cc',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/c26221dfe0b0d28c294a2dbe536536f2.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da61a3ddf897fde1a1cdcdc39926ecdc',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/42a52f65b40cc3b41d99b8f1723dc4d1.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54a5db25f28ee7a6e510faa9437b7ff4',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/f26331e3405a5673064f2464a8bd8893.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd24e456af1d0725f00ab6c7d33f355de',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/a7fa32b40a27084e0036dadd9630e5d8.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f90c268c8affd099ad62bde0797f8b37',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/01a39e9e7f76ced181a5f86461830c3d.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22762d61a4c7d79009e13ee8709b66ef',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/5b94c6bc8be7a16495096d238f275dee.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51d0ce9775d5bf4006188e4c856f9680',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/dfed82e77a9528f99b0a82c9232ae708.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd924abc79dd4eb858f141e21dcf6c560',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/34aff5027a6a0e87d8afc13047d5cf7e.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '826eaa919a2f77fbcec74d8e6d20cf18',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/2b6556ecdaa0f9556f9fcbf101775634.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3e227bf69adab7ea673dd37bad2ad78',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/844f43788011197e93a3c0bf2e043042.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13bf8ee62a814f718426a5f45bbcf6d5',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/2a92d10731b4801e0a7febb4365662c9.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42a17863c84187d24c45804bb1fffc3f',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/8aaa79fe32823b9ee27a58ae22081a79.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '978bb25750258bd504a5ebe909dcede0',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/b522b59e80cf14d4c3971759754b4dee.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9b9834ee9a08266ffecb571fb487948',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/2853f073786c44e85febaa674925f500.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b65ad086aeed0114e925d789d04d29c',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/e995301955099669a9d2ef7709f66ac0.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd2e9a5c1ccc84bd1933d889ce2a6409',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/ad52dcb72fbd7c6698043d9248582d17.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de914f240ff47e7faf4c68ac51d6a859',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/87b1f58130bd4670c6ef1b5b0f01d765.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d2a5133cf4b0cebac78475a37c900dc',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/c8a878ce31938e917321d95ac532ae7e.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b91f79a569857aa54ad439feadf0e15',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/3705fff14362a3f919ad0b5b0647b249.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '931b12095c5f4473584f058a1511b90d',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/58e85252a4e702a5a89253f2e55cea5c.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24e08a4639ad7ed46e9144e14ecbe2b0',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/b841778f01f00bd7166af09ba52c3113.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3ab9e7ddbf558d7fd4fefa95026ed33',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/46bb34476a56d58344b2829ed8438db4.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af45a869e09e35da93446ccbb9f7e54d',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/3fbe0657745ef0f31561f89e2b6577c9.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7fbc90e9349efcad16835070b6f6b12b',
      'native_key' => 'log_deprecated',
      'filename' => 'modSystemSetting/0365eda6e1e70c0de32ab0b7e5ca6636.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31688fd2d12916fe0bdfa826efc18eac',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/8f1ce89bc3c77fd01974a86976448438.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b246b4065dd9021144cbc359f348618',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/ed79549b792563dca2aaebe03feaa307.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cb56a9e7f4f644fe7de953d29df4c71',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/db0e18df6f156ed3d29fb17dbd76ef64.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '594267e70b18c5c5d8be45894e7ef090',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/552884570e359428d6a909ea74b59394.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14203f8bfefd0cf80ce2ac226aeb5515',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/010b81b85b55fba5ef8bb3075c81c594.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '400649544548325851a74db849bc32b8',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/3f657139c191d396161650df056cff07.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cc1982d31e88bcbf0ec96230a7a8577',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/edc95304be2fe37df755e8826d239edf.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7b9c877c0ce3fd9d15295964412cffd',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/8d0cffa15d64a22b8450bccd79533be5.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3208995ca813993572c9d993a4c024a5',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/05a34f9282c2cf98b4416086c96d4880.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e0a9e8a6ffab869e6e3ae370c7d6d4c',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/c251f0ce09df3cd17b962ca41e78dbef.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e218143c262b59c627fb3dcf09500e28',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/5d45aac1874a8a47ce4ae36f85e0ba72.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6486b4fda5defac4b0f9fcab0fe047fd',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/9970796e0a30a6e6584475c1d9cb9f2f.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7c5ba5fdf119902587d1a64d62dda9e',
      'native_key' => 'mail_smtp_autotls',
      'filename' => 'modSystemSetting/f5c6b71406af4675c42e9be0993a3b24.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e82bbdec223aa695896ab8c418942cb',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/98a22b7212b476b1c5ef767d18d61afd.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4858790446d4430c0619c79f9af332a8',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/abafe12d41b2e56fd2ec0b8bebc11fbb.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ebe19f1424191bc35a03136bdad3a41',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/8c2b003d6620dc2c22c7a8eb96716ada.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '436c85c53da18f90001b55adab40a843',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/5e8a1dfa03a1f0fb996ba0ac13f77f5c.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee2f19f7066e14aa7d6f25d62690d8f8',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/5eef865e5b3c861cf57afce567e08707.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37c774c078878b173cc9cb51a4f91e06',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/7223f4872db75f4faa972dfac5d636b3.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a2da5f5f695d5e099b5f488291d6ac2',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/7b9f2c246339d4b9c473355bebe8bd07.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6fd82c41133451cbbf5be82cf5b93769',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/0e6ac26e2cdc7c6c269ede94437f3ac1.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfe3853e9f0592034b7ef553f975bdf6',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/8d41ae77aa719414075f442a516c7f27.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42ce1b1f3753758a81ea4df7af1de839',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/ac3455c46943f9697e46a71bdfb59dae.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e2c487688ad36083f2b6f6dace0ba0b',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/299eb15e5254f7532251dfefc75ea076.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e66fa57566f07f2b0b199f2c65c925a6',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/d83e832a9cff6be892469b18055c2234.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a8100f395cf63b13a231336650a0bd1',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/a81a80159fcca09dc6d47bbfb95cbd60.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '326fa95a7b9bb68433cacb8eda892bbf',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/125902fa4a99b5f6981837a58540a229.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63f774a8b4565ac239c0b6bf77d44220',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/7cdc373eadfe183893ca32f88f7f1de6.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be80ccf57b64a3967198264d3ea6bb5c',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/5e99550d5795c58126dbc365ce4dd955.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'edf77c4df962c0ecb00284253de0fed3',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/357eccbf79f6e0e3a3c3732be73d6cbe.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f630fee1ceae6be5a1eb0e0109ab04ad',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/2ced41cafd16e46261c0ea7bb42c69c1.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10323157f6747f183058e0a78bebce9a',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/175c7ebe409a0984962b2b88d6e8de54.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5f5b9f5ac0f782971f217c7082666d6',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/9b219e0d95b72a925148b0a28d9a61cb.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efbf4afddde73bf571ea758b9effdb19',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/2cf3a64d55bb08476d6fbf987df2e19e.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7939a0ef085299da96baaaa40edbc68b',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/25b26a6becf8b3b0a4c5cb57e779052a.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa5baa9f9eeb2d910c61de63a9bba77e',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/332754922de599a1a51b43c53c3f3789.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0398aa02efa3ccff144641da91360967',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/67962670837a3bf973b967b00c0b7982.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32fa78eaadc959d9fe318cb3f9532c48',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/4a90a036ab377856710e4532c2d6bd67.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3cfe33ea32ce78ce02f5fc8f5f5206d',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/6843ab72a248374c09e83287d12d196c.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab035bd23d66e5e11ae85a22453c481c',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/7196eeb8161c4180b712383d3b6c7a54.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93a3f7c6850304e6c457b3bd28a1b8cc',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/10d592208b3d4f371f4e9fd9221aa21f.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81c7486f3c13cf9e8f8b20a4468402c3',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/a6912dcb5743f5e007a10e4b4ee1876a.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1541e74f8a3dd95ab3e321401c6e9582',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/72e804685b73c60b15d8139676ddd3f9.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8b7ef292ce9c8506000603267035ebf',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/8d1b3dc4b8cbf8b191af473ec40c911b.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f0783c87077cad23ef4d24b17c32d3f',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/da6f4b3bb3f37ff4332a9fe12ad7996d.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '433553ff4ed1dc175b61803cfcea79a4',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/1f3282e821470c7d540f30a1254a9d82.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '665c8046a586dd3aa831d5cfb5e9d75b',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/456cf156171a010add1c430234b7c4f0.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afa02237c89f2ab8f5d4dfd1c48f63b8',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/b6704eee589b96bd7136bcff7f6910ec.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9378ae72f5f5eac99b11bea488f4d30',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/02237988710095db90aec99e7dc38bf1.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe732a865d0fc23875466110c505c124',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/49a820bf23167f859daa5b34c6cd817b.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b8572a239b6944df3855ccf26645373',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/4b993273a7a57aae6138abc9e2efa0e6.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7172ff72dc7919b9e52b543ebd9ce4ca',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/cea9ce84614768185ca43b9b8ae76a82.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '810c043fd8322c6e85cb084608495a7c',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/48738471df63d2329f9817b93dacd569.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6dad507fe2262d57234642520b7c8195',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/bbd17a104d57aadf9a02be8290102738.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4768645cf2431a7d80cf5034c68a392f',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/8bad8da491cb6fe3dee4fa4d193d40cd.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1773efa24a3ce70017fe0ab97659381a',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/3ebeda2c606a548790132679a4ae8196.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c0721042b5e15d8fa5434704a656879',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/a36f541951fde76f5b6b362e780ab04a.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e83b5d6a5d3863a59f2601973291f17',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/e8189dff686300914dbf932ad6fc4225.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'adaf1bb9902a646d9a940fba4330d29b',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/4c5f0acac2493f97fb43818f717e3e54.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e182568f9f129e31d69d36a2970117e',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/0db612239d6c5eed7dcd928e98295758.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2997cd5f67cc86c02c1b5e24c5848af',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/d75628293c5b6d19e746692bbd659a04.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1828b3570314998b3b8b2c1b5df0e057',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/64a37d6fbaa0a81121bd733e710c1c13.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e35c355a0a36cccf900cab422e149f04',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/63e05f0feb6fe861a4ddd3337d051718.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7078fad90330a370de122659fd43427c',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/3c82e6de21fcf26fec3ba9b49c0c9e2d.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cedae127a43da7514b281d9e1cd3d6f',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/ba22f1ded96463cfe3594113325529bc.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a59572eee9696a75dd1aca40695e41e1',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/04c1b6fa774166b794b5b54f93b5eef6.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7bbfe6a083ae181fb296216ffe1d2fd',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/e53f55c406ca2ef592e23c59143e6fc7.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdf6b5180d32067c095a1cce3ab334b0',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/3d920efc3454bf7f1f8c91804acd28bf.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8efc914026d279117344ec4016bdcd7',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/1d56ac00995e87c5a581741336260c2d.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcd060beaa6abefdb35128bc4aa1683a',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/45715a1b787345acc316c9c10260f722.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '554d938779600e1e3912591abcb2b2de',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/a88ef1575c604a820f87d29d21cae9de.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05d374b4cc417af0aa65a233f850076b',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/9070bb755a0f8219c42a9e31b94cea55.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c212c77aadf54a202515d8e76716e136',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/09b248a5245f1d5a607961a285d4be0b.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec8f0b31156c42fc3fccedc7de92a303',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/816085b9512f09a573fbade3ed182629.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a41157e9eaa3e74ccb996fc4a92471b',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/51b55cb5ad98da2aebe3fe411e4900ce.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2701b345d4f7244c853e01bda8ef9a22',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/c650b8bf1d2862b818189c28f7e10b34.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a96c993cf515bcf816d50f0bf04ffc03',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/57040a80ca4679beff3ab19051e6ff72.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ee6193c16540a98a9bfe9c9d00ebc63',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/0c4e0ca7c6d9d526431ca7c48d4ecb46.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a22cd31b8f49aa6677e16a799b585b71',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/a40b6d7c52356f5364e488c5b26b5d8b.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4199dcb2e4b7a545667c453f01a753ba',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/4ef39684b48e99eaf5e5b2961ecd555b.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9187a1631977049b53832681288700f6',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/665c95d0759fb5f56cfc9c4a69941fc9.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a56dabbe11b0690f32a04b4e929dc292',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/ad4775cf19dc801a6ced86489b9ac1d0.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb44b3329e4fd7eb1e4e42fca959d94f',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/e92dd55eb53ec228ab5ed6aae08cb997.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8eddde72cee4f760056f710c1af25270',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/7122b70f54ca75281110f284d2bfda38.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65dec4c8f3e1c990f584ff700c0393e6',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/7974dd398c8fb494e8fca42cfb1bd261.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe8597ba0e8bbfa46bc07d09632eeffc',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/38cb14d74f8c1a34a128f083d8170d8c.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38ea42c3c2753fc0e5b8b106a7260582',
      'native_key' => 'session_cookie_samesite',
      'filename' => 'modSystemSetting/7c58306e837eb6df1342bf2bf04268cb.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbecae5ba7607e544afbe9fdbe1ac4ce',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/09a1e0feda95652175059391116f1249.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fadd9b006e10e4d83c7e069177ca8333',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/d79763317a9b46b1b34212ee1294fd2c.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63dd719ac0c1d5b1439929df2def05d6',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/748ba2118a0a52ed4f8ded994a5ee2eb.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e0b6ef569b645f94a32e332cf75c22b',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/ba10a69e31fd42d941271bd4d348d5ec.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05286f468cf68d7735f51d7168def53c',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/c113d8fe0b3da2ca1f6b90a29bcd9cc4.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afbf9dc1a1c79bb621382e14d8d88c6d',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/027eac75cc9e70cae0de339e6483093c.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12bf5c69b52cea4aa668f6160af42f98',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/8b1d7cba50cc20b943cdaafdfa47e80c.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8801cbdc96397f7fb60c6ec0bff45f7',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/5bae8ffcda9bdad98e9968893f6066bd.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bfd768ff8455a27b01b8f1c1c2d35bd',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/e15e644747123869e3c7c0c14bf8f9fe.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '714a5fe52de31666044ab24062282ea0',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/d3d6aefc5668e3a273d5b4ccfc3b04e3.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74b5a458c3cd80c555624a80722d9015',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/86c943d97a5f982a196464c16aba7e36.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91f9fb09e63692291636a2062f32e8f7',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/cded755192d0919ccec63fda947e1d30.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ce5d276222e8542af17ffd9c3eb13cf',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'modSystemSetting/2e0ab1a8123da8798d4cfc88809ba655.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1447ea5cb5293c943f538504d8608776',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'modSystemSetting/4d8ce53025d02f8be11ed34d454a04c9.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b0a9027d6ac95b5805baa2090dd7f08',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'modSystemSetting/a452dc9240fd544c8ba965e7ca6f4d0e.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6beb731460f92642aa0a2313e945d518',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'modSystemSetting/34bc314ac60128c2546faeb98df4a850.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a9b4339af6dfc6b54825ca8142ad4d6',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'modSystemSetting/a09b1e5dfff3a4969f2467c33f8ad666.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8c6bb0ce9f894bccfd3279578500bdb',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'modSystemSetting/6de47c8c6eb70642049867f5a9426828.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9522567f62cfad1eed8bcda7dde9377b',
      'native_key' => 'static_elements_default_category',
      'filename' => 'modSystemSetting/3308b042a3d9a6247c32f6aa86d8f54e.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5401dc3e14c82dddc2c318bcd91483b9',
      'native_key' => 'static_elements_basepath',
      'filename' => 'modSystemSetting/19af512290ed3c3d94ae93cefbcd48e2.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '448386c70e5a878b2bca45f8f9bfb4b0',
      'native_key' => 'resource_static_allow_absolute',
      'filename' => 'modSystemSetting/c957dd0e32b0447bb091f43ed424baaa.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1074909bbf2cbdefecb624760fefb3d6',
      'native_key' => 'resource_static_path',
      'filename' => 'modSystemSetting/24f885674375c124b15b7870ee2891ef.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7165749827e22e0455c92d64c17592d',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/3b53dedb4ed43d3aed73da3373422132.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffd277ebfcd007a6ca550f343199012c',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/1618c9af4542574fb991707dee05ed6c.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2d5c8c082330c7d5d0f3ca93b6aaafd',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/6c3ed391735caa4da534ecfeddd9bf52.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c7fdf6a01b1fe813986445cde64b528',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/4bb6ac91035fb3ada23cf9bd94e5934a.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ba65d4da68cf95ccb26df785d94a43d',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/a6cd13ba9005e6cc45015f60ea21cc08.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aad88540ed90c9be455479d913625eee',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/e750ee2aac5ed2679d16678da3738a02.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee27321d30c578fcb7b0f8bbc7356548',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/70eb922aa0ced70bce414afcf585194a.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37a75fc59069af1d7c640a2b0881c891',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/f64ab55a1565e7ba13aaa9e9233b68da.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0ddc23a69142d7da1cce00bbc99d802',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/9e3ed381c2e6799d95bc1d38e3678666.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9373b1e09ee6ae9346c3c6216a381df7',
      'native_key' => 'upload_check_exists',
      'filename' => 'modSystemSetting/38195d43306d7e7998d1912619ed2186.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea85730f6d3e3b722cafab3a30c7e4ba',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/70942b7dd7390cfa26cc4476805daf70.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf124955bc69fa48f39b526df9d6c9b0',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/1fcc323f7aff836d64be466c4ea79774.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '470254090f89c201fca9107a5776578f',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/8c3c54089c3dbfc009cb032d0f641c9e.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96123ca0726aa93478b80600011c280e',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/81d759596eeb5b5381387cee6ca107f8.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02ab5ffcb314c8fe48d12a3a82e49e4d',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/05e149777d5f3ff4cf98c8eb0e2ecb4b.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd1ab7f5cd502d57781990cfcf09451c',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/4e4d2051fe7643db8b177a0bc5061906.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2c2b2bba7f8be43b834f1a661ec4466',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/d32f25d3f601cccabdfc9016c63d6869.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd28d6d4a1ffae4d29218a6065ccc7828',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/c274a1f48d7f5c475f89f4301c6da29e.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de1aa8ab00d4b088a8b384fe4a13f245',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/afd5c0b027fa020bb3a9b9c9daf46f2a.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a725bc7321471f262fec8705e79ffccf',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/f44a72c0d9a69da93fd7aee85aae679a.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33d28d52cfb027e726927e16579fd29e',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/86cb84dcad3c65310cfd2757a77e6d2b.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8785a71ac7a41f4161d2a46f68f43147',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/10a05afacb023937b9b2714137a91333.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8894ffadd66f2de312a2f084fc381acf',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/6022f8e0a7267a98bca9af4aae60729e.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd64ad3b00a1fc731578260121a1f3e2a',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/e5b51002838a8899ccb5643e58690cb5.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f267c0c581346b8b7b92da0049942443',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/e436f4e6955636c312c2ed4e5e204285.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4babf4f68969cc64e568615630a7f452',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/c2936edffedc71b7864f004331f90a0c.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc1bec0eac347e8d6668d3b796920b09',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/7a32a40e4c7db37626228b56ef51f415.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b2bee32805ec30ab93d50bf7d090112',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/5f982982b3f7f07deb4ea843f07c3df7.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f730eeb4066af17d5bc4e231a1143406',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/e3286269c897d529faf90817a5f05e81.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bc10526799d1f4763858d1d329c20c7',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/c680b34dd179e0c1670befbba6bc990f.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fae7f60a4eaba4b860abadce1b01f966',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/dc24fd1f98bdfcfb51a1a476816c3137.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ae24051e635135a4b5cee3b5e5e65b6',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/51c2de096f817d40632ee7edbf1e9f1a.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04f92676296e6e96e81578756deddfd0',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/dc8d624670eee63d24f1e02cbdc7f6ef.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6ce1676ee91d5cbb37aa1f86eb9f08d',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/6bbdaedad4d84e12a09f48b6c09c9c47.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0beac5c4c95ada0804bdf460f02e94c7',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/d410cd3bc76d644bb771a7f0f56db8dd.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9fdcdf1c10f719d256c97bcc5553ba7',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/33296213f99c5455d3ec3fa460ac6ec7.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e86bdc292b2f4822a167a64aa9dea974',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/65c8ae19da284fb10edbd8b89943e471.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '564672323028e27cd5c5bbb6e77fe6f3',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/d53d0e31818df43a26df2b00addc5dc4.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7bd4ffb17130bd32289ea6c238f141e5',
      'native_key' => 'allow_tv_eval',
      'filename' => 'modSystemSetting/b01295db4c8151b00962ac6edc7d6b19.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f28619e4b0f6a59e2388ddfb3f283e9f',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/5a7a554dc40c11e6cb51c569fa6c3fcb.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e70bbd6a020afe019ecb88a1a8fe6c8e',
      'native_key' => 'error_log_filename',
      'filename' => 'modSystemSetting/1a97baa786521b032ad65a7ce2e4c9ae.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b67c304ca77651a4b3af93ab1011078',
      'native_key' => 'error_log_filepath',
      'filename' => 'modSystemSetting/0997c9f38ef153609dd225a60f6188c6.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45b0e35ea110df6a4f8a8845c41b993b',
      'native_key' => 'static_elements_html_extension',
      'filename' => 'modSystemSetting/d5bbf9dc0d4ffc93a7978e2588ff2f4b.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '8e89b059b6eab10a5ed7cc93c19a66a9',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/7826ab4811f354631fad9007b9b97940.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'dc1461213c77ea7460ea66f5ddc12f59',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/6b36c7de899f617806b33796f572764c.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'ca9e258de0cf412427411601cfbc8cc1',
      'native_key' => 1,
      'filename' => 'modUserGroup/3f79a081c596e164d758174d590a57c3.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'e3c978dda9a02bfb5acbcbc630e1cdf1',
      'native_key' => 1,
      'filename' => 'modDashboard/0dc99cb83eeb12a0175d40a6fd7384d4.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'bfaaf2d773ecaaf90557ca2135dc9024',
      'native_key' => 1,
      'filename' => 'modMediaSource/9b73af6684a29f95d66f60e560aa064c.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'b9bb591893190a004a6ec34d0cba88b0',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/92da4e03812049ede0c2b9d1c1e6a57d.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '25a5de984f3e512f5a1570b452c2e60e',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/4133a332fb6640160ffb156b8b7b308a.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'be5b19dd41300ce677941f3603a9dd9b',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/3991b4cfbceaf028e0a5a1272ff6f13c.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'a1effbc7d681dc01fd1e5fc78765fe09',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/406a9c85ad3029c07dbe996633f7209b.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '019e211451e8b2cfdaca61416c2f8b5e',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/c5d2ab2c7f5656525de6edba65b8a3ef.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'f5585009a8e0cdd6c69082b111bb7145',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/239dc6db49dfea0212ee5b1eb874c37d.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '4dee9677f353eb652c2c013d5bb95db3',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/b62839f42c86dd0f08f55da08a33fe48.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'a390105351216063840b62a3be026365',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/6382123f43e143a6da5372251e549986.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '88f43eea6427dd4c67fa3fcfc6aaffee',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/5e488fdef48286cfb0e3a2a1275ddd0b.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '3c4bde7a89215d26ce3f87d8bf9f2328',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/7c81e6eb377bfefb45f8842c376e634f.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'e03a969c2969f3ed8e765f0d8f9179c8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/5cd97b4e31b22683576eb7901c11ea2d.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'e4ad505702c7f96642f02b4c5646d7d0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/4f11e8bc6db6af93a0af1c23f69719fa.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '4ac5a6af217b0bab0798b17940c9b04e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/5fd562aca4da75527dee9ecaa77e61c7.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'f2c6574e7a4f12cdebece346c2f8c66c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/0cf935886b58627ecde853ba90ae727f.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'cb75d055e2d481c831fc858b157252d8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b24d978474f85a462e3e8364009e7a85.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '51f1e088a2d852336036184a9208b131',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/5bae1412216aa2fd568fadb89af1207c.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'da7ae799d2b3ad04a80ee355ec653d59',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/cb9cb784dc4c78dff61f15ca03123bf0.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'a5bd519b7c1cf418840fbd98bb23fed0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/bbdad4a4997d242f5e859f2c472b27b5.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b7ef7bf5a84ebf7805be8694367d6f8e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/a3da07abfb60ddad71ddc5905daa3d47.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'c1e4a62a909a695ee41779193434d214',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/31692f612b0d625af3477355ab22f5ee.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'af8df282049da2a2d124450444344aad',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/013110423c0b26b2a75c7dc618210afe.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '221e4979d8d57e89386b4ceced813b09',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/881c2cd6d2cec5e611e066f778bc596c.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '669546f14329e88d0653bc8a1059ca86',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/8168a289d2ffb0277d44cb034713433c.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3ebd656ce81e0d21e70963e4e7dd7323',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/920e06c87db444cff73e02e2b83bcb60.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd27babfe0c1578479fbb0084212e0667',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/c38751272abbf31ab9543bb1062b5327.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b9a22332073913054d1405b7dc4736ac',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/2d7a61aed583b8cb9ff74770cb9d3a40.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '59ecb9211f5fc51eb44df6edf2c72160',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/f92c56db01581177def4828d156a1d82.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8221e2db1ebee85976417b0ccdd57441',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/fe0d2560909a2be95c67291f5cce86f3.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2f98aacf1ac2621d2315c034b7faf31e',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/84f284f8d159e9bcdef855a41e8fc5a0.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ba9a11aa997a5416a0065a8c3422f5e5',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/3d816352db74cca3975b0d885b741136.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f2c4837b6bc84818346b34c7a7292df5',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/e8f51ed6ad3cfab8a197dab8745c9c56.vehicle',
    ),
    494 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a3458fefa7c72a12fc3b65af167d1980',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/4bad608e699b458d551f8029d3ff91ef.vehicle',
    ),
    495 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '2b9266e33e5f95cbc05402beb536d2c8',
      'native_key' => 'web',
      'filename' => 'modContext/6a791520c7737db68577772e5badeb1a.vehicle',
    ),
    496 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '18b696a262dfd4fcf3dc92288da8ddee',
      'native_key' => 'mgr',
      'filename' => 'modContext/5c047aa8e9fad7850c9b546ecb95b914.vehicle',
    ),
    497 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '9d8eef8e35a8887da57690c5bfed5871',
      'native_key' => '9d8eef8e35a8887da57690c5bfed5871',
      'filename' => 'xPDOFileVehicle/75d323d093f874fbfd0abaae5c91b843.vehicle',
    ),
    498 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'c14dd6ceddc0f607e1680005458207aa',
      'native_key' => 'c14dd6ceddc0f607e1680005458207aa',
      'filename' => 'xPDOFileVehicle/84a527693fea3f982af1035629319f9b.vehicle',
    ),
    499 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '002b01fc3edbaf16ac6cf296f51c66d8',
      'native_key' => '002b01fc3edbaf16ac6cf296f51c66d8',
      'filename' => 'xPDOFileVehicle/61882fe60691f0246cbfda2cf89a70fe.vehicle',
    ),
    500 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '1ce4b0c84a384370774f9e6d6bb3178d',
      'native_key' => '1ce4b0c84a384370774f9e6d6bb3178d',
      'filename' => 'xPDOFileVehicle/56d4579aab93fb2732f4f39dd03768e1.vehicle',
    ),
  ),
);